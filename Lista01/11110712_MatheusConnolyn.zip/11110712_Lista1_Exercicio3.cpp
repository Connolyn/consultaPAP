#include <iostream>

using namespace std;

int main()
{

	int t = 1;
	

	while(true){ 
		int n, winner = 0;
		cin >> n;
		

		if(n==0)break;

		for (int i = 1; i <= n; ++i)
		{
			int num;
			cin >> num;
			if(num == i) winner = i;

		}
		


		cout<<"Teste "<< t++ <<endl;

		cout << winner << endl << endl; 
	}	
	return 0;
}