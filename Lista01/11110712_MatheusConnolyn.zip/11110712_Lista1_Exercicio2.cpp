#include <iostream>

using namespace std;

int main()
{

	int t = 1;
	

	while(true){ 
		int n;
		cin >> n;
		
		if(n==0)break;

		int n50=0, n10=0, n5=0;
		
		n50 = n/50;
		n = n%50;
		cout << " 50 " << n50 << " sobrou " << n << endl; 

		n10 = n/10;
		n = n%10;
 
 		cout << " 10 " << n10 << " sobrou " << n << endl; 


		n5 = n/5;
		n = n%5;

		cout << " 5 " << n5 << " sobrou " << n << endl; 


		cout<<"Teste "<< t++ <<endl;

		cout << n50 << " " << n10 << " " << n5 << " " << n << endl << endl; 
	}	
	return 0;
}