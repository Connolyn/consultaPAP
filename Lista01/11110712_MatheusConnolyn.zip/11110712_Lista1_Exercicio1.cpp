#include <iostream>

using namespace std;

int main()
{
	int t = 1;
	
	while(true){ 
		int n, sum=0;
		cin >> n;	
		if(n==0)break;
		
		cin >> sum;
		for (int i = 1; i < n; ++i)
		{
			char op;
			int num;
			cin >> op;
			cin >> num;
			sum += (op=='+'?num: - num); 
		}

		cout<<"Teste "<< t++ <<endl;
		cout << sum << endl << endl;

	}	
	return 0;
}